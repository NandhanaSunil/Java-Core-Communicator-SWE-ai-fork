/**
 *  Generates insights after sentiment analysis.
 */
package com.swe.aiinsights.insightsgenerator;
