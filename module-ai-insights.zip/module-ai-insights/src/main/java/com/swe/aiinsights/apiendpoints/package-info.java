/**
 * Contains REST API controllers for AI image interpretation and regularisation.
 */
package com.swe.aiinsights.apiendpoints;
