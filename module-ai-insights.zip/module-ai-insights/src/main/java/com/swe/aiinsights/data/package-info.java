/**
 * Contains data model and representation
 * classes for the image processing application.
 */
package com.swe.aiinsights.data;
