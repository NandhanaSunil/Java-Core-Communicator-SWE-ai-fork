package com.swe.aiinsights.apiendpoints;



public class cloudSentimentAnalyserTest {




}